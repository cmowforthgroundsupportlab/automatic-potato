# TELTONIKA_FULL v1.6 (Fleet-safe, GitHub assets, Stage1/Stage2 .NET, BITS optional, HTTP resume, robust UCI apply + verify, Email)
$ErrorActionPreference = "Stop"

# =========================================================
# PATHS & LOGGING
# =========================================================
$BaseDir     = "C:\ProgramData\Teltonika"
$LogDir      = Join-Path $BaseDir "Logs"
$ScriptDir   = Join-Path $BaseDir "Scripts"
$LogFile     = Join-Path $LogDir "teltonika-pingreboot.log"

$SuccessFlag = Join-Path $BaseDir "success.flag"
$FailFlag    = Join-Path $BaseDir "fail.flag"

$BitsSkipFlag   = Join-Path $BaseDir "bits-broken.flag"
$BitsRepairFlag = Join-Path $BaseDir "bits-repair-attempted.flag"

$Stage2Flag  = Join-Path $BaseDir "stage2.flag"
$Stage2Task  = "TeltonikaStage2"

New-Item -ItemType Directory -Force -Path $BaseDir,$LogDir,$ScriptDir | Out-Null

function Log {
    param([string]$Msg)
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - $Msg"
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
    Write-Output $line
}

# Avoid HTML/login traps for downloads
function Test-NotHtml {
    param([string]$Path)
    try {
        $head = (Get-Content -LiteralPath $Path -TotalCount 25 -ErrorAction Stop | Out-String)
        if ($head -match '(?i)<!doctype|<html|login|sign in|microsoftonline|aadcdn|sharepoint') { return $false }
        return $true
    } catch { return $false }
}

function Get-ZipSignatureOK {
    param([string]$Path)
    try {
        $fs = [System.IO.File]::OpenRead($Path)
        try { $b1 = $fs.ReadByte(); $b2 = $fs.ReadByte() } finally { $fs.Dispose() }
        return ($b1 -eq 0x50 -and $b2 -eq 0x4B) # 'PK'
    } catch { return $false }
}

function Ensure-Tls12 {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
    try { [Net.ServicePointManager]::Expect100Continue = $false } catch {}
}

Ensure-Tls12

Log "=== Start (Teltonika Ping Reboot Apply) ==="
Log ("Running as: " + (whoami))

# =========================================================
# CONFIG
# =========================================================
$RouterPassword = "GSLali6ht71#"

# Desired router settings
$DesiredEnable        = 1
$DesiredIntervalMin   = 5
$DesiredTimeoutSec    = 10
$DesiredIntervalCount = 5  # also set retry=5 for GUI alignment on many firmwares

# GitHub release assets (NO SharePoint)
$DotNetUrl  = "https://github.com/cmowforthgroundsupportlab/automatic-potato/releases/download/v1.0/NDP48-x86-x64-AllOS-ENU.exe"
$PoshZipUrl = "https://github.com/cmowforthgroundsupportlab/automatic-potato/releases/download/v1.0/Posh-SSH.zip"

# Module install destination (SYSTEM-visible)
$ModuleRoot = "C:\Program Files\WindowsPowerShell\Modules"
$ModuleName = "Posh-SSH"

# =========================================================
# EMAIL REPORTING
# =========================================================
$EnableEmail = $true
$SmtpServer = "smtp.gmail.com"
$SmtpPort   = 587
$SmtpUser   = "chrismowforth1992@gmail.com"
$SmtpPass   = "toixkuymjhwntjoi"
$MailTo     = "cmowforth@groundsupportlabs.com"

function Send-ReportEmail {
    param([string]$Subject,[string]$Body)
    if (-not $EnableEmail) { return }
    try {
        $cred = New-Object PSCredential(
            $SmtpUser,
            (ConvertTo-SecureString $SmtpPass -AsPlainText -Force)
        )
        Send-MailMessage -SmtpServer $SmtpServer -Port $SmtpPort -UseSsl -Credential $cred `
            -From $SmtpUser -To $MailTo -Subject $Subject -Body $Body -ErrorAction Stop
        Log "Email report sent"
    } catch {
        Log "WARN: Email failed: $($_.Exception.Message)"
    }
}

# =========================================================
# OUTCOME TRACKING
# =========================================================
$Outcome  = "FAIL"
$ExitCode = 1
$RouterIp = $null

# =========================================================
# NETSTANDARD CHECK + STAGE1/STAGE2 .NET
# =========================================================
function Test-NetStandard {
    try { [void][System.Reflection.Assembly]::Load("netstandard"); return $true } catch {}
    $paths=@(
        "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\netstandard.dll",
        "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\netstandard.dll"
    )
    foreach($p in $paths){
        if(Test-Path $p){
            try { [void][System.Reflection.Assembly]::LoadFrom($p); return $true } catch {}
        }
    }
    return $false
}

# Download using BITS (if usable) then HTTP resume fallback.
function Try-RepairBITS {
    try {
        if (Test-Path $BitsRepairFlag) { return }
        New-Item -ItemType File -Path $BitsRepairFlag -Force | Out-Null

        Log "Attempting BITS repair (once): restarting services"
        foreach($svcName in @('BITS','COMSysApp','EventSystem')){
            try {
                $svc = Get-Service -Name $svcName -ErrorAction Stop
                Log ("Service {0} status={1} starttype={2}" -f $svcName,$svc.Status,$svc.StartType)
                if ($svc.Status -ne 'Running') { Start-Service -Name $svcName -ErrorAction SilentlyContinue }
            } catch {
                Log ("Service check failed for {0}: {1}" -f $svcName,$_.Exception.Message)
            }
        }

        foreach($dll in @('qmgr.dll','qmgrprxy.dll')){
            $p = Join-Path $env:WINDIR ("System32\{0}" -f $dll)
            if (Test-Path $p) {
                try { & regsvr32.exe /s $p; Log ("regsvr32 OK: {0}" -f $dll) }
                catch { Log ("regsvr32 failed ({0}): {1}" -f $dll,$_.Exception.Message) }
            }
        }
    } catch {
        Log "BITS repair attempt failed: $($_.Exception.Message)"
    }
}

function Download-HttpResume {
    param([string]$Url,[string]$OutFile,[int]$TimeoutSec)

    $partial = "$OutFile.partial"
    $have = 0L
    if (Test-Path $partial) {
        $have = (Get-Item $partial).Length
        Log ("HTTP(resume): found partial file {0} bytes" -f $have)
    }

    try {
        Add-Type -AssemblyName System.Net.Http -ErrorAction SilentlyContinue | Out-Null
    } catch {}

    $handler = New-Object System.Net.Http.HttpClientHandler
    $client  = New-Object System.Net.Http.HttpClient($handler)
    $client.Timeout = [TimeSpan]::FromSeconds($TimeoutSec)

    try {
        $req = New-Object System.Net.Http.HttpRequestMessage([System.Net.Http.HttpMethod]::Get, $Url)
        if ($have -gt 0) {
            $req.Headers.Range = New-Object System.Net.Http.Headers.RangeHeaderValue($have, $null)
            Log ("HTTP(resume): requesting Range bytes={0}-" -f $have)
        }

        $resp = $client.SendAsync($req, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
        Log ("HTTP status: {0} {1}" -f [int]$resp.StatusCode, $resp.ReasonPhrase)

        if ($have -gt 0 -and $resp.StatusCode -ne [System.Net.HttpStatusCode]::PartialContent) {
            Log "HTTP(resume): server did not return 206; restarting full download"
            Remove-Item $partial -Force -ErrorAction SilentlyContinue
            $have = 0
        }

        $resp.EnsureSuccessStatusCode() | Out-Null

        $inStream  = $resp.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
        $mode = if ($have -gt 0) { [System.IO.FileMode]::Append } else { [System.IO.FileMode]::Create }
        $outStream = New-Object System.IO.FileStream($partial, $mode, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)

        $sw = [Diagnostics.Stopwatch]::StartNew()
        [long]$lastLogged = $have

        try {
            $buffer = New-Object byte[] (1024 * 128)
            [long]$total = $have
            while (($read = $inStream.Read($buffer, 0, $buffer.Length)) -gt 0) {
                $outStream.Write($buffer, 0, $read)
                $total += $read
                if ($sw.Elapsed.TotalSeconds -ge 30) {
                    Log ("HTTP: progress total={0} (delta={1})" -f $total, ($total-$lastLogged))
                    $lastLogged = $total
                    $sw.Restart()
                }
            }
            $outStream.Flush()
            Log ("HTTP: stream ended at {0} bytes" -f $total)
        } finally {
            try { $outStream.Dispose() } catch {}
            try { $inStream.Dispose() } catch {}
        }

        Move-Item $partial $OutFile -Force
        Log ("HTTP: saved {0} bytes -> {1}" -f (Get-Item $OutFile).Length, $OutFile)
        return $true
    } finally {
        $client.Dispose()
        $handler.Dispose()
    }
}

function Download-FileWithRetry {
    param(
        [string]$Url,
        [string]$OutFile,
        [int]$Retries,
        [int]$BitsTimeoutSec,
        [int]$HttpTimeoutSec
    )

    for ($i=1; $i -le $Retries; $i++) {
        Log ("Download attempt {0}/{1} -> {2}" -f $i,$Retries,$OutFile)

        # BITS (optional)
        if (-not (Test-Path $BitsSkipFlag)) {
            try {
                Log ("BITS: starting (timeout {0}s)" -f $BitsTimeoutSec)
                $tmp = "$OutFile.bits.$PID"
                if (Test-Path $tmp) { Remove-Item $tmp -Force -ErrorAction SilentlyContinue }

                $job = Start-BitsTransfer -Source $Url -Destination $tmp -Asynchronous -Priority Foreground -ErrorAction Stop
                if (-not $job -or -not $job.Id) { throw "BITS returned null job (not usable on this machine)" }

                $sw = [Diagnostics.Stopwatch]::StartNew()
                while ($true) {
                    $j = Get-BitsTransfer -Id $job.Id -ErrorAction Stop
                    if ($j.JobState -eq 'Transferred') {
                        Complete-BitsTransfer -BitsJob $j -ErrorAction Stop
                        Move-Item $tmp $OutFile -Force
                        Log ("BITS: completed ({0} bytes)" -f (Get-Item $OutFile).Length)
                        return $true
                    }
                    if ($j.JobState -in @('Error','TransientError','Cancelled')) {
                        $err = $j.Error
                        $hr  = if ($err) { ('0x{0:X8}' -f ($err.ErrorCode -band 0xffffffff)) } else { '' }
                        try { Remove-BitsTransfer -BitsJob $j -Confirm:$false -ErrorAction SilentlyContinue } catch {}
                        throw ("BITS failed: state={0} {1} {2}" -f $j.JobState, $hr, ($err.Description))
                    }
                    if ($sw.Elapsed.TotalSeconds -ge $BitsTimeoutSec) {
                        try { Remove-BitsTransfer -Id $job.Id -Confirm:$false -ErrorAction SilentlyContinue } catch {}
                        throw ("BITS timeout after {0}s" -f $BitsTimeoutSec)
                    }
                    Start-Sleep -Seconds 2
                }
            } catch {
                Log ("BITS failed: {0}" -f $_.Exception.Message)
                if ($_.Exception.Message -match '(?i)0x80080005|CO_E_SERVER_EXEC_FAILURE|null job') {
                    Log ("BITS unusable. Creating skip flag: {0}" -f $BitsSkipFlag)
                    New-Item -ItemType File -Path $BitsSkipFlag -Force | Out-Null
                    Try-RepairBITS
                }
            }
        } else {
            Log ("BITS: skipped (flag present: {0})" -f $BitsSkipFlag)
        }

        # HTTP resume fallback
        try {
            Log ("HTTP: starting resume download (timeout {0}s)" -f $HttpTimeoutSec)
            if (Download-HttpResume -Url $Url -OutFile $OutFile -TimeoutSec $HttpTimeoutSec) { return $true }
        } catch {
            Log ("HTTP attempt failed: {0}" -f $_.Exception.Message)
            Start-Sleep -Seconds (5*$i)
        }
    }

    return $false
}

# Stage1: install .NET if missing netstandard
if (-not (Test-NetStandard)) {
    Log "NetStandard missing. Installing .NET Framework 4.8 then rebooting for Stage2..."
    $exe = Join-Path $BaseDir "ndp48.exe"

    $ok = Download-FileWithRetry -Url $DotNetUrl -OutFile $exe -Retries 3 -BitsTimeoutSec 120 -HttpTimeoutSec 600
    if (-not $ok) {
        Log "ERROR: Failed to download .NET installer"
        New-Item $FailFlag -Force | Out-Null
        $Outcome="FAIL"; $ExitCode=1
        throw "DotNet download failed"
    }

    # .NET installer should be big; sanity check
    $len = (Get-Item $exe).Length
    Log ("Downloaded .NET installer bytes={0}" -f $len)
    if ($len -lt 90000000 -or -not (Test-NotHtml -Path $exe)) {
        Log "ERROR: .NET installer looks invalid (too small or HTML)"
        New-Item $FailFlag -Force | Out-Null
        throw "DotNet invalid download"
    }

    Log "Launching .NET 4.8 installer..."
    $p = Start-Process -FilePath $exe -ArgumentList "/q /norestart" -PassThru
    $p.WaitForExit()
    Log ("DotNet installer exit code: {0}" -f $p.ExitCode)

    Log "Scheduling Stage2 task and rebooting"
    New-Item $Stage2Flag -Force | Out-Null
    schtasks /Create /TN $Stage2Task /SC ONSTART /RU SYSTEM /RL HIGHEST `
        /TR ("powershell.exe -NoProfile -ExecutionPolicy Bypass -File ""{0}""" -f $PSCommandPath) /F | Out-Null

    Restart-Computer -Force
    exit 0
}

# Stage2: cleanup task/flag
if (Test-Path $Stage2Flag) {
    try { Remove-Item $Stage2Flag -Force } catch {}
    try { schtasks /Delete /TN $Stage2Task /F | Out-Null } catch {}
    Log "Stage2 resumed after reboot"
}

# =========================================================
# MAIN
# =========================================================
try {
    # Router IP
    $RouterIp = (Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway } | Select-Object -First 1).IPv4DefaultGateway.NextHop
    if (-not $RouterIp) { throw "Could not determine router IP (default gateway)" }
    Log ("Router IP detected: {0}" -f $RouterIp)

    # Ensure module root exists
    New-Item -ItemType Directory -Force -Path $ModuleRoot | Out-Null

    # Posh-SSH ensure/import (offline if needed)
    $importOk = $false
    try {
        if (Get-Module -ListAvailable $ModuleName) {
            Import-Module $ModuleName -Force -ErrorAction Stop
            $importOk = $true
        }
    } catch { $importOk = $false }

    if (-not $importOk) {
        Log "Posh-SSH not importable - attempting offline install"
        $zip = Join-Path $BaseDir "Posh-SSH.zip"

        $ok = Download-FileWithRetry -Url $PoshZipUrl -OutFile $zip -Retries 3 -BitsTimeoutSec 120 -HttpTimeoutSec 600
        if (-not $ok) { throw "Failed to download Posh-SSH.zip" }

        $zlen = (Get-Item $zip).Length
        Log ("Downloaded Posh-SSH.zip bytes={0}" -f $zlen)

        if ($zlen -lt 1000000 -or -not (Get-ZipSignatureOK -Path $zip)) { throw "Downloaded Posh-SSH.zip is not a valid ZIP" }
        if (-not (Test-NotHtml -Path $zip)) { throw "Downloaded Posh-SSH.zip looks like HTML" }

        $stage = Join-Path $BaseDir "posh_stage"
        if (Test-Path $stage) { Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue }
        New-Item -ItemType Directory -Force -Path $stage | Out-Null

        Log ("Extracting Posh-SSH.zip -> {0}" -f $stage)
        Expand-Archive -Path $zip -DestinationPath $stage -Force

        # copy the module folder
        $src = Get-ChildItem -Path $stage -Directory -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq $ModuleName } | Select-Object -First 1
        if (-not $src) {
            # sometimes ZIP root is module itself
            $src = Get-ChildItem -Path $stage -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'Posh-SSH' } | Select-Object -First 1
        }
        if (-not $src) { throw "Could not locate Posh-SSH folder after unzip" }

        $dest = Join-Path $ModuleRoot $ModuleName
        if (Test-Path $dest) { Remove-Item $dest -Recurse -Force -ErrorAction SilentlyContinue }
        Log ("Installing module folder -> {0}" -f $dest)
        Copy-Item -Path $src.FullName -Destination $dest -Recurse -Force

        Import-Module $ModuleName -Force -ErrorAction Stop
    }

    Log "Posh-SSH imported"

    # Connectivity
    try {
        $tnc = Test-NetConnection -ComputerName $RouterIp -Port 22 -WarningAction SilentlyContinue
        Log ("Port 22 reachable: {0}" -f $tnc.TcpTestSucceeded)
        if (-not $tnc.TcpTestSucceeded) { throw "SSH port 22 not reachable" }
    } catch {
        throw ("SSH connectivity check failed: {0}" -f $_.Exception.Message)
    }

    # SSH
    $cred = New-Object PSCredential("root",(ConvertTo-SecureString $RouterPassword -AsPlainText -Force))
    Log "Opening SSH session..."
    $session = New-SSHSession -ComputerName $RouterIp -Credential $cred -AcceptKey -ErrorAction Stop
    Log "SSH session established."

    # Read current config
    Log "Reading current ping_reboot config (uci show + /etc/config)..."
    $preRes = Invoke-SSHCommand -SSHSession $session -Command "uci show ping_reboot; echo '---'; cat /etc/config/ping_reboot"
    $preOut = ($preRes.Output -join "`n")
    Log ("Router pre-state:`n{0}" -f $preOut)

    # Pick most populated section (0..3)
    $bestIdx = 0
    $bestCount = -1
    foreach($i in 0..3) {
        if ($preOut -match ("ping_reboot\.@ping_reboot\[{0}\]\.=" -f $i)) {
            $matches = [regex]::Matches($preOut, ("ping_reboot\.@ping_reboot\[{0}\]\.\w+=" -f $i))
            $c = $matches.Count
            if ($c -gt $bestCount) { $bestIdx = $i; $bestCount = $c }
        }
    }
    Log ("Selected ping_reboot section index: {0} (most populated)" -f $bestIdx)

    $sec = "ping_reboot.@ping_reboot[$bestIdx]"

    # Detect which timeout key is present (time_out vs timeout). If neither, set both.
    $hasTimeOut = ($preOut -match ([regex]::Escape($sec) + "\.time_out="))
    $hasTimeout = ($preOut -match ([regex]::Escape($sec) + "\.timeout="))
    $timeoutKey = if ($hasTimeout) { "timeout" } else { "time_out" }
    Log ("Timeout key selected: {0}" -f $timeoutKey)

    # Build apply command (no bash operators that confuse PowerShell)
    $applyLines = @()
    $applyLines += ("uci set {0}.enable='{1}'" -f $sec,$DesiredEnable)
    $applyLines += ("uci set {0}.interval='{1}'" -f $sec,$DesiredIntervalMin)
    $applyLines += ("uci set {0}.time='{1}'" -f $sec,$DesiredIntervalMin)
    $applyLines += ("uci set {0}.interval_count='{1}'" -f $sec,$DesiredIntervalCount)
    $applyLines += ("uci set {0}.retry='{1}'" -f $sec,$DesiredIntervalCount)

    if ($hasTimeOut -or -not $hasTimeout) { $applyLines += ("uci set {0}.time_out='{1}'" -f $sec,$DesiredTimeoutSec) }
    if ($hasTimeout -or -not $hasTimeOut) { $applyLines += ("uci set {0}.timeout='{1}'"  -f $sec,$DesiredTimeoutSec) }

    # Delete empty extra sections that only have enable=0 (0..4)
    foreach($i in 0..4) {
        if ($i -ne $bestIdx) {
            $pattern = "ping_reboot\.@ping_reboot\[{0}\]\.enable='0'" -f $i
            $onlyEnable = $false
            if ($preOut -match ("ping_reboot\.@ping_reboot\[{0}\]\.=" -f $i)) {
                $all = [regex]::Matches($preOut, ("ping_reboot\.@ping_reboot\[{0}\]\.\w+=" -f $i)).Count
                if ($all -le 2 -and ($preOut -match $pattern)) { $onlyEnable = $true }
            }
            if ($onlyEnable) {
                Log ("Will delete empty extra section: {0}" -f $i)
                $applyLines += ("uci -q delete ping_reboot.@ping_reboot[{0}]" -f $i)
            }
        }
    }

    $applyLines += "uci commit ping_reboot"
    $applyLines += "/etc/init.d/ping_reboot restart"
    $applyLines += "uci show ping_reboot"

    $applyCmd = ($applyLines -join "`n")

    Log "Applying settings via SSH..."
    $res = Invoke-SSHCommand -SSHSession $session -Command $applyCmd -ErrorAction Stop
    $out = ($res.Output -join "`n")
    Log ("Router output:`n{0}" -f $out)

    Remove-SSHSession -SSHSession $session | Out-Null

    # Verify
    $ok =
        ($out -match "enable='1'") -and
        ($out -match "interval='5'") -and
        ($out -match "interval_count='5'") -and
        ($out -match "retry='5'") -and
        ($out -match "(time_out|timeout)='10'")

    if (-not $ok) { throw "Verification failed (settings not all present)" }

    # Success flags
    Set-Content -Path $SuccessFlag -Value ("{0} {1}" -f (Get-Date -Format s), $RouterIp)
    if (Test-Path $FailFlag) { Remove-Item $FailFlag -Force -ErrorAction SilentlyContinue }

    Log ("SUCCESS: Ping reboot enabled and values set on {0} (IntervalMin=5, TimeoutSec=10, Tries=5)" -f $RouterIp)
    $Outcome="SUCCESS"; $ExitCode=0
}
catch {
    Log ("ERROR: Exception: {0}" -f $_.Exception.Message)
    New-Item $FailFlag -Force | Out-Null
    $Outcome="FAIL"
    if ($ExitCode -eq 0) { $ExitCode = 1 }
}
finally {
    try {
        $tail = (Get-Content $LogFile -Tail 60 | Out-String)
        $ipForSubject = if ($RouterIp) { $RouterIp } else { "no-router-ip" }
        if (Test-Path $SuccessFlag) {
            Send-ReportEmail -Subject ("TELTONIKA SUCCESS - {0} - {1}" -f $env:COMPUTERNAME,$ipForSubject) -Body $tail
        } else {
            Send-ReportEmail -Subject ("TELTONIKA FAIL - {0} - {1}" -f $env:COMPUTERNAME,$ipForSubject) -Body $tail
        }
    } catch {
        Log ("WARN: Email reporting block failed: {0}" -f $_.Exception.Message)
    }

    Log ("=== End ({0}) ===" -f $Outcome)
}

exit $ExitCode
